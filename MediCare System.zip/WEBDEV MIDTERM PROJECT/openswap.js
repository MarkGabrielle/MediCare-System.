
const SWAP_REQUEST_KEY = "medicareSwapRequests";

function getSwapRequests() {
    return JSON.parse(localStorage.getItem(SWAP_REQUEST_KEY)) || [];
}

function saveSwapRequests(requests) {
    localStorage.setItem(SWAP_REQUEST_KEY, JSON.stringify(requests));
}

function showShiftTab(tab) {
    const openSection = document.getElementById("openSection");
    const swapSection = document.getElementById("swapSection");

    if (!openSection || !swapSection) return;

    openSection.classList.toggle("hidden", tab !== "open");
    swapSection.classList.toggle("hidden", tab !== "swap");

    document.getElementById("openTab").classList.toggle("active", tab === "open");
    document.getElementById("swapTab").classList.toggle("active", tab === "swap");
}

function setSwapMinimumDate() {
    const dateInput = document.getElementById("swapDate");
    if (!dateInput) return;

    const today = new Date();
    const localToday = new Date(
        today.getTime() - today.getTimezoneOffset() * 60000
    ).toISOString().split("T")[0];

    dateInput.min = localToday;
}

function getCurrentStaff() {
    return {
        id: sessionStorage.getItem("staffID") || "",
        name: sessionStorage.getItem("staffName") || "",
        role: sessionStorage.getItem("account") || ""
    };
}

function initializeSwapStaff() {
    const currentStaff = getCurrentStaff();
    const staffInput = document.getElementById("swapStaff");
    const targetSelect = document.getElementById("targetStaff");

    if (staffInput) {
        staffInput.value = currentStaff.id;
    }

    if (!targetSelect) return;

    targetSelect.innerHTML =
        '<option value="">Select staff member</option>';

    const staffList = typeof staffMembers !== "undefined"
        ? staffMembers
        : [];

    staffList.forEach(staff => {
        if (staff.id === currentStaff.id) return;

        const option = document.createElement("option");
        option.value = staff.id;
        option.textContent = `${staff.name} - ${staff.position}`;
        option.dataset.name = staff.name;

        targetSelect.appendChild(option);
    });
}

function displayMySwapRequests() {
    const container = document.getElementById("myShiftRequests");
    if (!container) return;

    const currentStaff = getCurrentStaff();
    const requests = getSwapRequests().filter(request =>
        request.requesterID === currentStaff.id ||
        request.requesteeID === currentStaff.id
    );

    if (requests.length === 0) {
        container.innerHTML = "<p>No requests submitted yet.</p>";
        return;
    }

    container.innerHTML = requests.map(request => {
        let status = request.status;

        if (request.requesteeResponse === "Accepted" &&
            request.status === "Waiting for staff response") {
            status = "Waiting for HR approval";
        }

        return `
            <div class="request-item">
                <h3>Swap Request</h3>
                <p><strong>Requester:</strong> ${escapeHTML(request.requesterName)}</p>
                <p><strong>Requested Staff:</strong> ${escapeHTML(request.requesteeName)}</p>
                <p><strong>Date:</strong> ${escapeHTML(request.swapDate)}</p>
                <p><strong>Status:</strong> ${escapeHTML(status)}</p>
            </div>
        `;
    }).join("");
}

function escapeHTML(value) {
    return String(value || "").replace(/[&<>"']/g, character => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[character]);
}

function submitSwapRequest(event) {
    event.preventDefault();

    const currentStaff = getCurrentStaff();
    const targetSelect = document.getElementById("targetStaff");
    const targetOption = targetSelect.options[targetSelect.selectedIndex];
    const evidence = document.getElementById("swapEvidence").files[0];
    const swapDate = document.getElementById("swapDate").value;
    const message = document.getElementById("swapMessage");

    if (!currentStaff.id || !currentStaff.name) {
        message.textContent = "Please log in using your staff account first.";
        return;
    }

    if (!targetOption || !targetOption.value) {
        message.textContent = "Please select the staff member.";
        return;
    }

    if (targetOption.value === currentStaff.id) {
        message.textContent = "You cannot request a swap with yourself.";
        return;
    }

    if (!evidence) {
        message.textContent = "Please upload supporting evidence.";
        return;
    }

    const today = new Date();
    const localToday = new Date(
        today.getTime() - today.getTimezoneOffset() * 60000
    ).toISOString().split("T")[0];

    if (!swapDate || swapDate < localToday) {
        message.textContent = "Past dates are not allowed.";
        return;
    }

    if (evidence.size > 2 * 1024 * 1024) {
        message.textContent = "Please upload a file smaller than 2 MB.";
        return;
    }

    const reader = new FileReader();

    reader.onload = function () {
        const requests = getSwapRequests();

        const newRequest = {
            id: "SWAP-" + Date.now(),
            requesterID: currentStaff.id,
            requesterName: currentStaff.name,
            requesteeID: targetOption.value,
            requesteeName: targetOption.dataset.name ||
                targetOption.textContent,
            requesterSchedule: document.getElementById("mySchedule").value.trim(),
            requesteeSchedule: document.getElementById("targetSchedule").value.trim(),
            swapDate: swapDate,
            reason: document.getElementById("swapReason").value.trim(),
            evidenceName: evidence.name,
            evidenceData: reader.result,
            requesteeResponse: "Pending",
            status: "Waiting for staff response",
            createdAt: new Date().toISOString()
        };

        requests.push(newRequest);
        saveSwapRequests(requests);

        message.textContent =
            "Swap request sent! Waiting for the other staff member's response.";

        message.style.color = "#0f766e";

        document.getElementById("swapForm").reset();
        initializeSwapStaff();
        setSwapMinimumDate();
        displayMySwapRequests();
    };

    reader.onerror = function () {
        message.textContent = "Unable to read the uploaded evidence.";
    };

    reader.readAsDataURL(evidence);
}

document.addEventListener("DOMContentLoaded", function () {
    if (document.getElementById("swapForm")) {
        initializeSwapStaff();
        setSwapMinimumDate();
        displayMySwapRequests();

        document.getElementById("swapForm")
            .addEventListener("submit", submitSwapRequest);
    }
        displayStaffNotifications();
     
});

function displayStaffNotifications() {
    const container = document.getElementById("staffNotifications");
    if (!container) return;

    const currentID = sessionStorage.getItem("staffID");
    if (!currentID) {
        container.innerHTML = "<p>Please log in to view notifications.</p>";
        return;
    }

    const requests = getSwapRequests().filter(request =>
        request.requesterID === currentID ||
        request.requesteeID === currentID
    );

    if (requests.length === 0) {
        container.innerHTML = "<p>No notifications yet.</p>";
        return;
    }

    container.innerHTML = requests.map(request => {
        const isRequester = request.requesterID === currentID;
        let statusMessage = "";
        let actions = "";

        if (request.status === "Rejected") {
            statusMessage = "This swap request was declined.";
        } else if (request.status === "Approved") {
            statusMessage = "HR approved the schedule replacement.";
        } else if (request.status === "HR Rejected") {
            statusMessage = "HR rejected the schedule replacement.";
        } else if (request.requesteeResponse === "Accepted") {
            statusMessage = "Both staff members agreed. Waiting for HR approval.";
        } else if (request.requesteeResponse === "Declined") {
            statusMessage = "The requested staff member declined the request.";
        } else if (isRequester) {
            statusMessage = "Waiting for " +
                escapeHTML(request.requesteeName) + "'s response.";
        } else {
            statusMessage = escapeHTML(request.requesterName) +
                " wants to swap schedules with you.";

            actions = `
                <button type="button"
                    onclick="respondToSwap('${request.id}', 'Accepted')">
                    Accept
                </button>

                <button type="button"
                    onclick="respondToSwap('${request.id}', 'Declined')">
                    Decline
                </button>
            `;
        }

        return `
            <div class="request-item">
                <h3>Schedule Swap Request</h3>
                <p><strong>From:</strong> ${escapeHTML(request.requesterName)}</p>
                <p><strong>To:</strong> ${escapeHTML(request.requesteeName)}</p>
                <p><strong>Date:</strong> ${escapeHTML(request.swapDate)}</p>
                <p>${statusMessage}</p>
                ${actions}
            </div>
        `;
    }).join("");
}

function respondToSwap(requestID, response) {
    const currentID = sessionStorage.getItem("staffID");
    const requests = getSwapRequests();

    const request = requests.find(item => item.id === requestID);

    if (!request) return;

    if (request.requesteeID !== currentID) {
        alert("Only the requested staff member can respond.");
        return;
    }

    if (request.requesteeResponse !== "Pending") {
        alert("You have already responded to this request.");
        return;
    }

    request.requesteeResponse = response;

    if (response === "Accepted") {
        request.status = "Waiting for HR approval";
    } else {
        request.status = "Rejected";
    }

    saveSwapRequests(requests);

    displayStaffNotifications();
    displayMySwapRequests();

    alert(response === "Accepted"
        ? "You accepted the swap request. It is now waiting for HR approval."
        : "You declined the swap request.");
}
